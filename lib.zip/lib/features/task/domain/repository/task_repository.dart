import 'package:task_manager_app/features/task/domain/entities/task.dart';

abstract class TaskRepository<T> {
  List<Task> get();
  List<Task> search(String title);
  void add(T tasks);
  void update(String id, T task);
  void delete(String id);
}
